package ca.bcit.comp2526.tictactoe;

public class Main
{
    public static void main(final String[] argv)
    {
    }
}
