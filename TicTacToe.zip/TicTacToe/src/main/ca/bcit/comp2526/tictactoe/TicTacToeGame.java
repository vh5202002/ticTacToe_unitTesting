package ca.bcit.comp2526.tictactoe;

import ca.bcit.comp2526.game.board.BoardGame;

public class TicTacToeGame
    extends BoardGame
{
}
