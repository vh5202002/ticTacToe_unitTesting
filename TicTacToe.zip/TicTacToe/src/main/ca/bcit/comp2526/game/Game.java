package ca.bcit.comp2526.game;

public abstract class Game
{
}
