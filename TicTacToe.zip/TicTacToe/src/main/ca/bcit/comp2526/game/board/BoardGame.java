package ca.bcit.comp2526.game.board;

import ca.bcit.comp2526.game.Game;

public abstract class BoardGame
    extends Game
{
}
