package ca.bcit.comp2526.game.board;

public class Square
{
}
